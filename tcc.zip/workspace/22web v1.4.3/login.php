<!DOCTYPE html>
<html>
<head>

<?php
session_start();
include('includes/links.php');

if (isset($_SESSION['login'])) {
  if ($_SESSION['login']==1) {

  if ($_SESSION['chave']==1) {
    header('location:admin.php');
  }

  if ($_SESSION['chave']==2) {
    header('location:professor.php');
  }

  if ($_SESSION['chave']==3) {
    header('location:responsavel.php');
  }
   
}
}

  ?>

  <meta charset="utf-8">

	<title>22WEB| Login</title>
</head>
<body>

	<style type="text/css">
		
		#login{
			margin-top: 6%;
		}

	</style>

<div class="content">

	<div class="row">

		<div class="col s8 offset-s2">
	  <div class="card" id='login'>
    <div class="card-image waves-effect waves-block waves-light">
      <img class="activator" src="images/1.jpg" id='cidade'>
    </div>
    <div class="card-content">
      <span class="card-title activator grey-text text-darken-4">Login<i class="material-icons right">more_vert</i></span>
      <p><a href="visitante.php">Visite a página de visitante</a></p>
    </div>
    <div class="card-reveal">
      <span class="card-title grey-text text-darken-4">Login<i class="material-icons right">close</i></span>
      <p>
      	<form method='post' enctype="multipart/form-data">
      		
          <div class="row">
          <div class="input-field col s8 m7 l6">
          <input id='nome' type="text" name="nome" class="validate">
          <label for="nome">Nome</label>
          </div>

          <div class="input-field col s4 m5 l6">
          <input  id='cpf' type="text" name="cpf" class="validate">
          <label for="cpf">CPF</label>
          </div>
          </div>

          <div class="row">
          
          <div class="input-field col s11 m11 l11">
          <input  id='senha' type="text" name="senha" class="validate" >
          <label for="senha">Senha</label>
          </div>
          
          <div class="col s1 m1 l1">
            <input type="button" class="btn btn-floating teal darken-4" id='mandar' name='mandar_login'>

          </div>
          
          </div>
          
        <script type="text/javascript">
  
            $(document).ready(function(){
            $("#mandar").click(function(){

              var dados = {'nome': $('#nome').val(), 'senha': $('#senha').val(), 'cpf' : $('#cpf').val() };

               $.ajax({
                type:'POST',
                url:'ajax/login.php',
                data: dados,

                success : function(response){
                  if(response.trim() == "location.href = 'professor.php';"){
                  eval(response);
                  $('.validate').css('border-color', 'green');
                }

                if(response.trim() == "location.href = 'responsavel.php';"){
                  eval(response);
                  $('.validate').css('border-color', 'green');
                }

              if(response.trim() == "location.href = 'admin.php';"){
                  eval(response);
                  $('.validate').css('border-color', 'green');
                }

                else{
                  $('.validate').css('border-color', 'red');
                }
                }

               });
            });
          });

          </script>

      	</form>
      </p>
    </div>
  </div>
</div>
	
</div>
</div>

</body>
</html>



