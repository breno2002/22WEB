<?php

session_start();

include('../conexao.php');

$senha = $_POST['senha'];
$nome = $_POST['nome'];
$cpf = $_POST['cpf'];

$sql = 'select * from tb_usuario';

$query_u = $mysqli -> query($sql);

while ($row_u = $query_u->fetch_array()) {

  if ($row_u['nm_usuario']==$nome) {
    if ($row_u['ds_senha']==$senha) {
      if ($row_u['ds_cpf']==$cpf) {

        $_SESSION['login'] = 1;
        $_SESSION['cd_usuario'] = $row_u['cd_usuario'];
        
        if ($row_u['id_tipodeusuario']==3) {

           $_SESSION['chave'] = 3;
          echo "location.href = 'responsavel.php';";

        }

        if($row_u['id_tipodeusuario']==2){
          $_SESSION['chave'] = 2;
          echo "location.href = 'professor.php';";
        }

        if ($row_u['id_tipodeusuario']==1) {
          $_SESSION['chave'] = 1;
          echo "location.href = 'admin.php';";
        }

        }
      }
    }
  }




?>