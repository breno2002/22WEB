<?php
session_start();
include('../conexao.php');

  $recado = $_POST['recado'];
  $tipoderecado = $_POST['select_tipo'];
  $cd_destinatario = $_POST['select_destinatario'];

      $sql_recado = 'insert into tb_recado values(null, "'.$recado.'", "'.$cd_destinatario.'", "'.$_SESSION['cd_usuario'].'", "'.$tipoderecado.'")';

      $query_recado = $mysqli->query($sql_recado);
                        
?>

