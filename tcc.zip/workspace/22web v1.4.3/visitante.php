<!DOCTYPE html>
  <html>

    <head>

  <link rel="stylesheet" href="css/materialize.css">

  <link rel="stylesheet" href="css/materialize.min.css">
 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   <!-- Compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">

  <!-- Compiled and minified JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
          
  <script src="materialize/js/jquery.min.js"></script>
  <script src="materialize/js/bin/materialize.min.js"></script>
  <script src="materialize/js/app.js"></script>
            

      <title>22WEB|Página inicial</title>
      <meta charset="utf-8"></head>

    </head>

      
       <nav id="menu">
        <div class="nav-wrapper">
          <a href="#" class="brand-logo">Logo</a>
          <ul id="nav-mobile" class="right hide-on-med-and-down">

            <!-- Modal Trigger -->
          <li><a class= "modal-trigger" href="#modal1"><i class="material-icons">directions_run</i></a></li>

          <script>
  
            $(document).ready(function(){
            $('.modal, #modal1').modal();
          });
          
          </script>

          </ul>
        </div>
      </nav>

      <div class="row" id='menu2'>
          <div class="col s12">

          </div>
      </div>

      

      <div class="row" id='container'>
        <div class="col s12">

          </div>
      </div>

       <div class="row" id='container2'>
        <div class="col s12">

          </div>
      </div>

      <div class="row" id='container3'>
        <div class="col s12">

          </div>
      </div>

      <div class="row" id='container4'>
        <div class="col s12">

          </div>
      </div>

       <div class="row" id='container5'>
        <div class="col s12">

          </div>
      </div>

      <div id="modal1" class="modal">
          <div class="modal-content" id='ovo'>
            <form method="post">
           <p><center><text>Você deseja sair?</text></center></p> 
            <center>
              <button type='submit' value='logoff' name='sair' class='btn'>Sim</button>
            <a href="#!" class="modal-close waves-effect waves-green btn-flat">Não</a>
            </center>
            </form>
          </div>
        </div>

  </html>

  <style type="text/css">
    #menu{
      background:grey;
      height: 70px;
      position: sticky;
      top: 0px;
    }

    #menu2{
      background:black;
      height: 100px;
      top: 0px;
      position: sticky;

    }

    #container{
      height: 600px;
      background: white;
    }

    #container2{
      height: 200px;
      background: grey;
    }

    #container3{
      height: 600px;
      background: white;
    }

    #container4{
      height: 700px;
      background: grey;
    }

    #container5{
      height: 400px;
      background: white;
    }

    .modal{
      z-index: 100;
    }

  </style>
