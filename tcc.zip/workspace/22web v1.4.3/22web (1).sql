-- phpMyAdmin SQL Dump
-- version 4.0.4.2
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 22-Jun-2019 às 22:25
-- Versão do servidor: 5.6.13
-- versão do PHP: 5.4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `22web`
--
CREATE DATABASE IF NOT EXISTS `22web` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `22web`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_aluno`
--

CREATE TABLE IF NOT EXISTS `tb_aluno` (
  `cd_aluno` int(11) NOT NULL AUTO_INCREMENT,
  `nm_aluno` varchar(50) NOT NULL,
  `ds_turma` varchar(50) NOT NULL,
  `ds_sexo` varchar(30) NOT NULL,
  `ds_periodo` varchar(40) NOT NULL,
  `ds_endereco` varchar(100) NOT NULL,
  `ds_rg` varchar(20) NOT NULL,
  `ds_telefone` varchar(20) NOT NULL,
  `id_sozinho` int(11) NOT NULL,
  `vl_idade` int(11) NOT NULL,
  PRIMARY KEY (`cd_aluno`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `tb_aluno`
--

INSERT INTO `tb_aluno` (`cd_aluno`, `nm_aluno`, `ds_turma`, `ds_sexo`, `ds_periodo`, `ds_endereco`, `ds_rg`, `ds_telefone`, `id_sozinho`, `vl_idade`) VALUES
(1, 'a', 'a', 'a', 'a', 'a', 'a', 'a', 1, 1),
(2, 'come&nbspcome', 'a', 'a', 'a', 'a', 'a', 'a', 1, 1),
(3, 'come come', 'a', 'a', 'a', 'a', 'a', 'a', 1, 1),
(4, 'come come', 'a', 'a', 'a', 'a', 'a', 'a', 1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_aluno_responsavel`
--

CREATE TABLE IF NOT EXISTS `tb_aluno_responsavel` (
  `cd_aluno_responsavel` int(11) NOT NULL AUTO_INCREMENT,
  `id_aluno` int(11) NOT NULL,
  `id_usuario_responsavel` int(11) NOT NULL,
  PRIMARY KEY (`cd_aluno_responsavel`),
  KEY `id_aluno` (`id_aluno`),
  KEY `id_usuario_responsavel` (`id_usuario_responsavel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_estado`
--

CREATE TABLE IF NOT EXISTS `tb_estado` (
  `Cd_estado` int(11) NOT NULL AUTO_INCREMENT,
  `Nm_estado` varchar(20) DEFAULT NULL,
  `Vl_sigla` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`Cd_estado`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Extraindo dados da tabela `tb_estado`
--

INSERT INTO `tb_estado` (`Cd_estado`, `Nm_estado`, `Vl_sigla`) VALUES
(1, 'Acre', 'AC'),
(2, 'Alagoas', 'AL'),
(3, 'Amazonas', 'AM'),
(4, 'Amapá', 'AP'),
(5, 'Bahia', 'BA'),
(6, 'Ceará', 'CE'),
(7, 'Distrito Federal', 'DF'),
(8, 'Espírito Santo', 'ES'),
(9, 'Goiás', 'GO'),
(10, 'Maranhão', 'MA'),
(11, 'Minas Gerais', 'MG'),
(12, 'Mato Grosso do Sul', 'MS'),
(13, 'Mato Grosso', 'MT'),
(14, 'Pará', 'PA'),
(15, 'Paraíba', 'PB'),
(16, 'Pernambuco', 'PE'),
(17, 'Piauí', 'PI'),
(18, 'Paraná', 'PR'),
(19, 'Rio de Janeiro', 'RJ'),
(20, 'Rio Grande do Norte', 'RN'),
(21, 'Rondônia', 'RO'),
(22, 'Roraima', 'RR'),
(23, 'Rio Grande do Sul', 'RS'),
(24, 'Santa Catarina', 'SC'),
(25, 'Sergipe', 'SE'),
(26, 'São Paulo', 'SP'),
(27, 'Tocantins', 'TO');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_materia`
--

CREATE TABLE IF NOT EXISTS `tb_materia` (
  `cd_materia` int(11) NOT NULL AUTO_INCREMENT,
  `nm_materia` varchar(20) NOT NULL,
  `id_usuario_professor` int(11) NOT NULL,
  PRIMARY KEY (`cd_materia`),
  KEY `id_usuario_professor` (`id_usuario_professor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_nota`
--

CREATE TABLE IF NOT EXISTS `tb_nota` (
  `cd_nota` int(11) NOT NULL AUTO_INCREMENT,
  `id_aluno` int(11) NOT NULL,
  `id_materia` int(11) NOT NULL,
  `ds_bimestre` varchar(20) NOT NULL,
  `nm_nota` varchar(20) NOT NULL,
  `vl_peso_nota` int(11) NOT NULL,
  `vl_nota` double(2,2) NOT NULL,
  PRIMARY KEY (`cd_nota`),
  KEY `id_aluno` (`id_aluno`),
  KEY `id_materia` (`id_materia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_recado`
--

CREATE TABLE IF NOT EXISTS `tb_recado` (
  `cd_recado` int(11) NOT NULL AUTO_INCREMENT,
  `ds_recado` varchar(500) NOT NULL,
  `id_usuario_receber` int(11) NOT NULL,
  `id_usuario_mandar` int(11) NOT NULL,
  `id_tiporecado` int(11) NOT NULL,
  PRIMARY KEY (`cd_recado`),
  KEY `id_usuario_receber` (`id_usuario_receber`),
  KEY `id_usuario_mandar` (`id_usuario_mandar`),
  KEY `id_tiporecado` (`id_tiporecado`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=134 ;

--
-- Extraindo dados da tabela `tb_recado`
--

INSERT INTO `tb_recado` (`cd_recado`, `ds_recado`, `id_usuario_receber`, `id_usuario_mandar`, `id_tiporecado`) VALUES
(118, 'aaaa', 8, 1, 3),
(119, 'aaaaaaaaaaaaa', 8, 1, 1),
(120, '', 8, 1, 1),
(121, '', 8, 1, 1),
(122, '', 8, 1, 1),
(123, '', 8, 1, 1),
(124, '', 8, 1, 1),
(125, '', 8, 1, 1),
(126, 'aaaaaaaaaaaaaaa', 8, 1, 1),
(127, 'aaaaaaaaaaaaaaa', 8, 1, 1),
(129, '', 8, 1, 1),
(130, '', 8, 1, 1),
(131, '', 8, 1, 1),
(132, '', 8, 1, 1),
(133, 'aaaaaaa', 8, 1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_tipodeusuario`
--

CREATE TABLE IF NOT EXISTS `tb_tipodeusuario` (
  `cd_tipodeusuario` int(11) NOT NULL AUTO_INCREMENT,
  `nm_tipodeusuario` varchar(40) NOT NULL,
  PRIMARY KEY (`cd_tipodeusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `tb_tipodeusuario`
--

INSERT INTO `tb_tipodeusuario` (`cd_tipodeusuario`, `nm_tipodeusuario`) VALUES
(1, 'Responsável'),
(2, 'Professor'),
(3, 'administrador');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_tiporecado`
--

CREATE TABLE IF NOT EXISTS `tb_tiporecado` (
  `cd_tiporecado` int(11) NOT NULL AUTO_INCREMENT,
  `nm_tiporecado` varchar(30) NOT NULL,
  `ds_cor` varchar(40) NOT NULL,
  PRIMARY KEY (`cd_tiporecado`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `tb_tiporecado`
--

INSERT INTO `tb_tiporecado` (`cd_tiporecado`, `nm_tiporecado`, `ds_cor`) VALUES
(1, 'urgente', '#b71c1c'),
(2, 'padrão', '#ffb74d'),
(3, 'evento', '#29b6f6');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_usuario`
--

CREATE TABLE IF NOT EXISTS `tb_usuario` (
  `cd_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nm_usuario` varchar(30) NOT NULL,
  `id_tipodeusuario` int(11) DEFAULT NULL,
  `ds_senha` varchar(30) DEFAULT NULL,
  `ds_cpf` varchar(20) NOT NULL,
  `ds_rg` varchar(20) NOT NULL,
  `ds_telefone` varchar(20) DEFAULT NULL,
  `ds_idade` int(3) NOT NULL,
  `ds_celular` varchar(20) DEFAULT NULL,
  `ds_ddd` varchar(5) DEFAULT NULL,
  `ds_complemento` varchar(100) DEFAULT NULL,
  `ds_bairro` varchar(100) DEFAULT NULL,
  `ds_cidade` varchar(100) DEFAULT NULL,
  `dt_inscricao` varchar(30) DEFAULT NULL,
  `ds_estado` varchar(100) DEFAULT NULL,
  `ds_foto` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`cd_usuario`),
  UNIQUE KEY `ds_cpf` (`ds_cpf`),
  UNIQUE KEY `ds_rg` (`ds_rg`),
  KEY `id_tipodeusuario` (`id_tipodeusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Extraindo dados da tabela `tb_usuario`
--

INSERT INTO `tb_usuario` (`cd_usuario`, `nm_usuario`, `id_tipodeusuario`, `ds_senha`, `ds_cpf`, `ds_rg`, `ds_telefone`, `ds_idade`, `ds_celular`, `ds_ddd`, `ds_complemento`, `ds_bairro`, `ds_cidade`, `dt_inscricao`, `ds_estado`, `ds_foto`) VALUES
(1, 'a a', 2, 'a', 'a', 'a', 'a', 1, 'a', 'a', 'a', 'a', 'a', '2019.06.16-19.31.42', 'a', 'fotos/professores/2019.06.16-19.31.42.png'),
(8, 'a a', 1, 'a', '32', '23', '1', 123, '1', '1', '1', '1', '1', '2019.06.16-20.01.13', '1', 'fotos/responsaveis/a a.png');

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `tb_aluno_responsavel`
--
ALTER TABLE `tb_aluno_responsavel`
  ADD CONSTRAINT `tb_aluno_responsavel_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `tb_aluno` (`cd_aluno`),
  ADD CONSTRAINT `tb_aluno_responsavel_ibfk_2` FOREIGN KEY (`id_usuario_responsavel`) REFERENCES `tb_usuario` (`cd_usuario`);

--
-- Limitadores para a tabela `tb_materia`
--
ALTER TABLE `tb_materia`
  ADD CONSTRAINT `tb_materia_ibfk_1` FOREIGN KEY (`id_usuario_professor`) REFERENCES `tb_usuario` (`cd_usuario`);

--
-- Limitadores para a tabela `tb_nota`
--
ALTER TABLE `tb_nota`
  ADD CONSTRAINT `tb_nota_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `tb_aluno` (`cd_aluno`),
  ADD CONSTRAINT `tb_nota_ibfk_2` FOREIGN KEY (`id_materia`) REFERENCES `tb_materia` (`cd_materia`);

--
-- Limitadores para a tabela `tb_recado`
--
ALTER TABLE `tb_recado`
  ADD CONSTRAINT `tb_recado_ibfk_4` FOREIGN KEY (`id_tiporecado`) REFERENCES `tb_tiporecado` (`cd_tiporecado`),
  ADD CONSTRAINT `tb_recado_ibfk_1` FOREIGN KEY (`id_usuario_receber`) REFERENCES `tb_usuario` (`cd_usuario`),
  ADD CONSTRAINT `tb_recado_ibfk_2` FOREIGN KEY (`id_usuario_mandar`) REFERENCES `tb_usuario` (`cd_usuario`),
  ADD CONSTRAINT `tb_recado_ibfk_3` FOREIGN KEY (`id_tiporecado`) REFERENCES `tb_tiporecado` (`cd_tiporecado`);

--
-- Limitadores para a tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  ADD CONSTRAINT `tb_usuario_ibfk_1` FOREIGN KEY (`id_tipodeusuario`) REFERENCES `tb_tipodeusuario` (`cd_tipodeusuario`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
