<!DOCTYPE html>
<html>
<head>

	<?php 

  session_start();
  date_default_timezone_set("Brazil/East"); //Definindo timezone padrão
  include('includes/links.php');
  include('conexao.php');

  if (isset($_SESSION['login'])) {
  if ($_SESSION['login']==1) {

  if ($_SESSION['chave']==1) {
    header('location:admin.php');
  }

  if ($_SESSION['chave']==2) {
    header('location:professor.php');
  }
   
}
}

else{
  header('location:login.php');
}

  ?>
	<title>22WEB| Área do responsável</title>
</head>
<body>  

	<form method="post" multipart='enctype/form-data'>
  <div class="row">
    
    <div class="col s5 m4 l3" id='menu'>
      <ul>
        <p>
          <h4>Responsável</h4>
          <li><a href='#modal_sair' class="modal-trigger">deslogar</a></li>
        </p>
      </ul>
    </div>

    <style type="text/css">
      #menu{
        background: black;
        text-decoration-color: white;
        height: 500%;
      }

      #menu, a{
        color: white;
      }

    </style>

   
    <div class="col s4 m5 l6" id='recados'>
      <ul>

        <p>

          <?php 

          $sql_mensagem = 'select * from tb_mensagem';

          $query_mensagem = $mysqli->query($sql_mensagem);

          while ($row_msg = fetch_array($query_mensagem)) {
            echo $row_msg.'<br>';
          }

          ?>

        </p>
        
        <p>
          <textarea name="recado" id='recado'></textarea>
        </p>
      </ul>
    </div>

     <div class="col s2 m2 l1">
      <input type="text" name="tipo_recado">
    </div>

     <div class="col s2 m2 l1">
      <select name='select_destinatario' id='select'>
        <?php
        $sql_pessoas = 'select * from tb_usuario';

        if ($query_pessoas = $mysqli->query($sql_pessoas)) {
          while ($row_pessoas = $query_pessoas->fetch_array()) {
              if ($row_pessoas['cd_usuario'] == $_SESSION['cd_usuario']){
              }

              else{
                echo '<option name="destinatario" value="'.$row_pessoas['cd_usuario'].'">'.$row_pessoas['nm_usuario'].'</option>';  
              }
          }
        }

        
        ?>
      </select>

      <script type="text/javascript">
          $(document).ready(function(){
            $('select').formSelect();
          });

          $(document).ready(function(){
            $("#mandar").click(function(){

              var dados = {'destinatario': $('#select').val(), 'tipo': $('#tipo_recado').val(), 'recado' : $('#recado').val() };

               $.ajax({
                type:'POST',
                url:'ajax/recado.php',
                data: dados,

                success : function(response){
                  eval(response);
                }

               });
            });
          });

      </script>
    </div>

    <div class="col s2 m2 l1">
      <input type="submit" name="enviar_recado">
    </div>
  </div>
  </form>


	<script>
  
            $(document).ready(function(){
            $('.modal, #modal_aluno').modal();
            $('.modal, #modal_responsavel').modal();
            $('.modal, #modal_professor').modal();
            $('.modal, #modal_sair').modal();
             // Show sideNav
                   $('.button-collapse').sideNav('show');
          });
          
  </script>

</body>
</html>

<style type="text/css">
	#menu{
		height: 200px;
	}

	#radio{
		height: 40px;
	}
</style>
