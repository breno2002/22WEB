<meta charset="utf-8">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      
      <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	  <script src="materialize/js/jquery.min.js"></script>
	  <script src="materialize/js/bin/materialize.min.js"></script>
	  <script src="materialize/js/app.js"></script>
