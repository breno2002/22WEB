<form method="post" enctype="multipart/form-data" name='professor'>

<div id="modal_professor" class="modal">
          <div class="modal-content" id='conteudo_modal_professor'>
            <div class="col s8 offset-s2">


              <div class="card" id='cadastro_professor_css'>

                  <div class="card-image waves-effect waves-block waves-light">
                    <img class="activator" src="images/1.jpg" id='cidade'>
                  </div>
                  <div class="card-content">

                    <span class="card-title activator grey-text text-darken-4">Cadastrar Professor<i class="material-icons right">more_vert</i></span>

                  </div>
                  <div class="card-reveal">
                    <span class="card-title grey-text text-darken-4">Cadastrar<i class="material-icons right">close</i></span>
                    <p>
                      <form method='post' enctype="multipart/form-data">
                        
                        <div class="row">
                        <div class="input-field col s8 m7 l6">
                        <input  id='nome' type="text" name="nome_professor" class="validate">
                        <label for="nome">Nome do professor</label>
                        </div>

                        <div class="input-field col s4 m5 l6">
                        <input  id='sobrenome' type="text" name="sobrenome_professor" class="validate" onkeypress="$(this).mask('00000000000');" >
                        <label for="sobrenome">Sobrenome do professor</label>
                        </div>

                        
                        </div>

                        <div class="row">
                           <div class="input-field col s5 m4 l3">
                          <input  id='senha_professor' type="text" name="senha_professor" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="senha_professor">Senha</label>
                          </div>

                           <div class="input-field col s7 m8 l9">
                          <input  id='senha2_professor' type="text" name="senha2_professor" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="senha2_professor">Confirmar senha</label>
                          </div>
                        </div>

                        <div class="row">
                          
                          <div class="input-field col s5 m5 l5">
                          <input  id='rg_professor' type="text" name="rg_professor" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="rg_professor">RG</label>
                          </div>

                          <div class="input-field col s5 m4 l5">
                          <input  id='cpf_professor' type="text" name="cpf_professor" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="cpf_professor">CPF</label>
                          </div>

                           <div class="input-field col s2 m3 l2">
                          <input  id='idade_professor' type="number" name="idade_professor" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="idade_professor">Idade</label>
                          </div>

                        </div>

                        <div class="row">

                          <div class="input-field col s2 m2 l2">
                          <input  id='ddd_professor' type="text" name="ddd_professor" class="validate" onkeypress="$(this).mask('00');" >
                          <label for="ddd_professor">DDD</label>
                          </div>
                          
                          <div class="input-field col s5 m5 l5">
                          <input  id='celular_professor' type="text" name="celular_professor" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="celular_professor">celular</label>
                          </div>

                           <div class="input-field col s5 m5 l5">
                          <input  id='telefone_professor' type="text" name="telefone_professor" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="telefone_professor">telefone</label>
                          </div>

                        </div>

                          <div class="row">

                          <div class="input-field col s1 m1 l1">
                          <input  id='estado_professor' type="text" name="estado_professor" class="validate" onkeypress="$(this).mask('00');" >
                          <label for="estado_professor">Estado</label>
                          </div>
                          
                          <div class="input-field col s3 m4 l4">
                          <input  id='cidade_professor' type="text" name="cidade_professor" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="cidade_professor">Cidade</label>
                          </div>

                           <div class="input-field col s3 m4 l4">
                          <input  id='bairro_professor' type="text" name="bairro_professor" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="bairro_professor">Bairro</label>
                          </div>

                          <div class="input-field col s3 m3 l3">
                          <input  id='complemento_professor' type="text" name="complemento_professor" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="complemento_professor">Complemento</label>
                          </div>

                        </div>


                        <div class="row">
                        
                        <div class="input-field col s12 m12 l12">

                          <div class='col s11 m11 l11'>
                             <div class="file-field input-field">
                                  <div class="btn">
                                    <span>Carregar arquivo</span>
                                    <input type="file" name='foto_professor' id='foto_professor'>
                                  </div>
                                  <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text">
                                  </div>
                                </div>
                          </div>
                          
                          <div class="col s1 m1 l1">
                                <button class="btn btn-floating teal darken-4" id='mandar_professor' value='mandar_professor' name="mandar_professor">
                                    <i class="material-icons right">send</i>   
                                </button>
                              </div>
                          
                        </div>

                        </div>

                              

                       </form>
                      </p>
                    </div>
                  </div>


    </div>
         </div>
       </div>

     </form>