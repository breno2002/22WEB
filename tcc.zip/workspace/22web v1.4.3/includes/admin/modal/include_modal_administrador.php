<form method="post" enctype="multipart/form-data" name='administrador'>

<div id="modal_administrador" class="modal">
          <div class="modal-content" id='conteudo_modal_administrador'>
            <div class="col s8 offset-s2">


              <div class="card" id='cadastro_administrador_css'>

                  <div class="card-image waves-effect waves-block waves-light">
                    <img class="activator" src="images/1.jpg" id='cidade'>
                  </div>
                  <div class="card-content">

                    <span class="card-title activator grey-text text-darken-4">Cadastrar administrador<i class="material-icons right">more_vert</i></span>

                  </div>
                  <div class="card-reveal">
                    <span class="card-title grey-text text-darken-4">Cadastrar<i class="material-icons right">close</i></span>
                    <p>
                      <form method='post' enctype="multipart/form-data">
                        
                        <div class="row">
                        <div class="input-field col s8 m7 l6">
                        <input  id='nome_administrador' type="text" name="nome_administrador" class="validate">
                        <label for="nome_administrador">Nome do administrador</label>
                        </div>

                        <div class="input-field col s4 m5 l6">
                        <input  id='sobrenome_administrador' type="text" name="sobrenome_administrador" class="validate" onkeypress="$(this).mask('00000000000');" >
                        <label for="sobrenome_administrador">Sobrenome do administrador</label>
                        </div>

                        
                        </div>

                        <div class="row">
                           <div class="input-field col s5 m4 l3">
                          <input  id='senha_administrador' type="text" name="senha_administrador" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="senha_administrador">Senha</label>
                          </div>

                           <div class="input-field col s7 m8 l9">
                          <input  id='senha2_administrador' type="text" name="senha2_administrador" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="senha2_administrador">Confirmar senha</label>
                          </div>
                        </div>

                        <div class="row">
                          
                          <div class="input-field col s5 m5 l5">
                          <input  id='rg_administrador' type="text" name="rg_administrador" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="rg_administrador">RG</label>
                          </div>

                          <div class="input-field col s5 m4 l5">
                          <input  id='cpf_administrador' type="text" name="cpf_administrador" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="cpf_administrador">CPF</label>
                          </div>

                           <div class="input-field col s2 m3 l2">
                          <input  id='idade_administrador' type="number" name="idade_administrador" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="idade_administrador">Idade</label>
                          </div>

                        </div>

                        <div class="row">

                          <div class="input-field col s2 m2 l2">
                          <input  id='ddd_administrador' type="text" name="ddd_administrador" class="validate" onkeypress="$(this).mask('00');" >
                          <label for="ddd_administrador">DDD</label>
                          </div>
                          
                          <div class="input-field col s5 m5 l5">
                          <input  id='celular_administrador' type="text" name="celular_administrador" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="celular_administrador">Celular</label>
                          </div>

                           <div class="input-field col s5 m5 l5">
                          <input  id='telefone_administrador' type="text" name="telefone_administrador" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="telefone_administrador">Telefone</label>
                          </div>

                        </div>

                          <div class="row">

                          <div class="input-field col s1 m1 l1">
                          <input  id='estado_administrador' type="text" name="estado_administrador" class="validate" onkeypress="$(this).mask('00');" >
                          <label for="estado_administrador">Estado</label>
                          </div>
                          
                          <div class="input-field col s3 m4 l4">
                          <input  id='cidade_administrador' type="text" name="cidade_administrador" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="cidade_administrador">Cidade</label>
                          </div>

                           <div class="input-field col s3 m4 l4">
                          <input  id='bairro_administrador' type="text" name="bairro_administrador" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="bairro_administrador">Bairro</label>
                          </div>

                          <div class="input-field col s3 m3 l3">
                          <input  id='complemento_administrador' type="text" name="complemento_administrador" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="complemento_administrador">Complemento</label>
                          </div>

                        </div>


                        <div class="row">
                        
                        <div class="input-field col s12 m12 l12">

                             <div class='col s11 m11 l11'>
                             <div class="file-field input-field">
                                  <div class="btn">
                                    <span>Carregar arquivo</span>
                                    <input type="file" name='foto_administrador' id='foto_administrador'>
                                  </div>
                                  <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text">
                                  </div>
                                </div>
                              </div>
                              
                              <div class="col s1 m1 l1">
                                <button class="btn btn-floating teal darken-4" id='mandar_administrador' name='mandar_administrador'>
                                    <i class="material-icons right">send</i>   
                                </button>
                              </div>
                              
                        </div>

                        </div>

                       

                       </form>
                      </p>
                    </div>
                  </div>


    </div>
         </div>
       </div>

</form>