<form method="post" enctype="multipart/form-data" name='responsavel'>

<div id="modal_responsavel" class="modal">
          <div class="modal-content" id='conteudo_modal_responsavel'>
            <div class="col s8 offset-s2">


              <div class="card" id='cadastro_responsavel_css'>

                  <div class="card-image waves-effect waves-block waves-light">
                    <img class="activator" src="images/1.jpg" id='cidade'>
                  </div>
                  <div class="card-content">

                    <span class="card-title activator grey-text text-darken-4">Cadastrar responsavel<i class="material-icons right">more_vert</i></span>

                  </div>
                  <div class="card-reveal">
                    <span class="card-title grey-text text-darken-4">Cadastrar<i class="material-icons right">close</i></span>
                    <p>
                      <form method='post' enctype="multipart/form-data">
                        
                        <div class="row">
                        <div class="input-field col s8 m7 l6">
                        <input  id='nome_responsavel' type="text" name="nome_responsavel" class="validate">
                        <label for="nome_responsavel">Nome do responsavel</label>
                        </div>

                        <div class="input-field col s4 m5 l6">
                        <input  id='sobrenome_responsavel' type="text" name="sobrenome_responsavel" class="validate" onkeypress="$(this).mask('00000000000');" >
                        <label for="sobrenome_responsavel">Sobrenome do responsavel</label>
                        </div>

                        
                        </div>

                        <div class="row">
                           <div class="input-field col s5 m4 l3">
                          <input  id='senha_responsavel' type="text" name="senha_responsavel" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="senha_responsavel">Senha</label>
                          </div>

                           <div class="input-field col s5 m4 l3">
                          <input  id='senha2_responsavel' type="text" name="senha2_responsavel" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="senha2_responsavel">Confirmar senha</label>
                          </div>
                        </div>

                        <div class="row">
                          
                          <div class="input-field col s5 m4 l3">
                          <input  id='rg_responsavel' type="text" name="rg_responsavel" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="rg_responsavel">RG</label>
                          </div>

                          <div class="input-field col s3 m3 l3">
                          <input  id='cpf_responsavel' type="text" name="cpf_responsavel" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="cpf_responsavel">CPF</label>
                          </div>

                           <div class="input-field col s3 m3 l3">
                          <input  id='idade_responsavel' type="number" name="idade_responsavel" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="idade_responsavel">Idade</label>
                          </div>

                        </div>

                        <div class="row">

                          <div class="input-field col s1 m1 l1">
                          <input  id='ddd_responsavel' type="text" name="ddd_responsavel" class="validate" onkeypress="$(this).mask('00');" >
                          <label for="ddd_responsavel">DDD</label>
                          </div>
                          
                          <div class="input-field col s3 m4 l5">
                          <input  id='celular_responsavel' type="text" name="celular_responsavel" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="celular_responsavel">Celular</label>
                          </div>

                           <div class="input-field col s3 m4 l5">
                          <input  id='telefone_responsavel' type="text" name="telefone_responsavel" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="telefone_responsavel">Telefone</label>
                          </div>

                        </div>

                          <div class="row">

                          <div class="input-field col s1 m1 l1">
                          <input  id='estado_responsavel' type="text" name="estado_responsavel" class="validate" onkeypress="$(this).mask('00');" >
                          <label for="estado_responsavel">Estado</label>
                          </div>
                          
                          <div class="input-field col s3 m4 l4">
                          <input  id='cidade_responsavel' type="text" name="cidade_responsavel" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="cidade_responsavel">Cidade</label>
                          </div>

                           <div class="input-field col s3 m4 l4">
                          <input  id='bairro_responsavel' type="text" name="bairro_responsavel" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="bairro_responsavel">Bairro</label>
                          </div>

                          <div class="input-field col s3 m3 l3">
                          <input  id='complemento_responsavel' type="text" name="complemento_responsavel" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="complemento_responsavel">Complemento</label>
                          </div>

                        </div>


                        <div class="row">
                        
                        <div class="input-field col s12 m12 l12">

                             <div class="file-field input-field">
                                  <div class="btn">
                                    <span>Carregar arquivo</span>
                                    <input type="file" name='foto_responsavel' id='foto_responsavel'>
                                  </div>
                                  <div class="file-path-wrapper">
                                    <input class="file-path validate" type="text">
                                  </div>
                                </div>
                        </div>

                        </div>

                              <div class="row">
                              <div class="col s4 m4 l4">
                                <button class="btn btn-floating teal darken-4" id='mandar_responsavel' name='mandar_responsavel'>
                                    <i class="material-icons right">send</i>   
                                </button>
                              </div>
                             </div>

                       </form>
                      </p>
                    </div>
                  </div>


    </div>
         </div>
       </div>

</form>