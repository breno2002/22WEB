<div id="modal_aluno" class="modal">
          <div class="modal-content" id='ovo'>
            <div class="col s8 offset-s2">


              <div class="card" id='cadastro_aluno_css'>

                  <div class="card-image waves-effect waves-block waves-light">
                    <img class="activator" src="images/1.jpg" id='cidade'>
                  </div>

                  <div class="card-content">
                    <span class="card-title activator grey-text text-darken-4">Cadastrar Aluno<i class="material-icons right">more_vert</i></span>
                  </div>

                  <div class="card-reveal">
                    
                    <span class="card-title grey-text text-darken-4">Cadastrar Aluno<i class="material-icons right">close</i></span>
                   
                     <p>
                      <form method='post' enctype="multipart/form-data" name='aluno'>
                        
                        <div class="row">
                        <div class="input-field col s8 m7 l6">
                        <input  id='nome' type="text" name="nome_aluno" class="validate">
                        <label for="nome">Nome do Aluno</label>
                        </div>

                        <div class="input-field col s4 m5 l6">
                        <input  id='sobrenome' type="text" name="sobrenome_aluno" class="validate" onkeypress="$(this).mask('00000000000');" >
                        <label for="sobrenome">Sobrenome</label>
                        </div>

                        
                        </div>

                        <div class="row">
                          
                          <div class="input-field col s8 m7 l6">
                          <input  id='rg' type="text" name="rg_aluno" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="rg">RG</label>
                          </div>
                          
                          <div class="input-field col s4 m5 l6">
                          <input  id='telefone' type="text" name="telefone_aluno" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="telefone">telefone</label>
                          </div>

                        </div>

                        <div class="row">
                        
                        <div class="input-field col s12 m12 l12">

                          <div class="input-field col s8 m7 l6">
                          <input  id='turma' type="text" name="turma_aluno" class="validate" onkeypress="$(this).mask('00000000000');" >
                          <label for="turma">turma</label>
                          </div>

                          <div class="input-field col s4 m5 l6">
                          <input  id='endereco' type="text" name="endereco_aluno" class="validate" onkeypress="$(this).mask('00 00000 0000');" >
                          <label for="endereco">endereco</label>
                          </div>
                          
                        </div>

                        </div>



                        <div class="row">
                        
                        <div class="input-field col s12 m12 l12">

                          <div class="input-field col s8 m7 l6">
                          <input  id='sexo' type="text" name="sexo_aluno" class="validate">
                          <label for="sexo">sexo</label>
                          </div>

                          <div class="input-field col s4 m5 l6">
                          <input  id='idade' type="number" name="idade_aluno" class="validate">
                          <label for="idade">idade</label>
                          </div>
                          
                        </div>

                        </div>

                        <div class="row">
                        
                        <div class="input-field col s12 m12 l12">

                          <div class="input-field col s4 m3 l3">
                          <input  id='periodo' type="text" name="periodo_aluno" class="validate">
                          <label for="periodo">periodo</label>
                          </div>

                          <div class="input-field col s4 m5 l6">
                          <input  id='sozinho' type="number" name="sozinho_aluno" class="validate">
                          <label for="sozinho">sozinho</label>
                          </div>
                          
                        </div>

                        </div>

                              <div class="row">
                              <div class="col s4 m4 l4">
                                <button class="btn btn-floating teal darken-4" id='mandar_aluno' name='mandar_aluno' value='mandar'>
                                    <i class="material-icons right">send</i>   
                                </button>
                              </div>
                             </div>

                       </form>
                      </p>
                  </div>
                </div>


    </div>
         </div>
       </div>
