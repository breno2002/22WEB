
<?php
if (isset($_POST['mandar_aluno'])) {
  
  $nome_aluno = $_POST['nome_aluno'].' '.$_POST['sobrenome_aluno'];
  $rg_aluno = $_POST['rg_aluno'];
  $telefone_aluno = $_POST['telefone_aluno'];
  $turma_aluno = $_POST['turma_aluno'];
  $endereco_aluno = $_POST['endereco_aluno'];
  $sexo_aluno = $_POST['sexo_aluno'];
  $idade_aluno = $_POST['idade_aluno'];
  $periodo_aluno = $_POST['periodo_aluno'];
  $sozinho_aluno = $_POST['sozinho_aluno'];

  $sql_aluno = 'insert into tb_aluno values(null, "'.$nome_aluno.'", "'.$turma_aluno.'", "'.$sexo_aluno.'", "'.$periodo_aluno.'", "'.$endereco_aluno.'", "'.$rg_aluno.'", "'.$telefone_aluno.'", "'.$sozinho_aluno.'", "'.$idade_aluno.'");';

  if(!$mysqli->query($sql_aluno)){
     echo "Error%s/n", $mysqli -> error;
  }
  
}
?>