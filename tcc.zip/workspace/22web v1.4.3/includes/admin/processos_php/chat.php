<?php

  if (isset($_POST['enviar_msg'])) {
  
      $recado = $_POST['recado'];
      $tipoderecado = $_POST['select_tipo'];
      $cd_destinatario = $_POST['select_destinatario'];

      $sql_recado = 'insert into tb_mensagem values(null, "'.$recado.'", "'.$_SESSION['cd_usuario'].'", "'.$cd_destinatario.'")';

      if (!$query_recado = $mysqli->query($sql_recado)){
                        
         echo "Error%s/n", $mysqli -> error;
      }

     echo ' <meta http-equiv="refresh" content="0.0000001" />';
     
        }
  ?>