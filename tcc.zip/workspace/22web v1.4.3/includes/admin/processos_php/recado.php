<?php

  if (isset($_POST['enviar_recado'])) {
  
      $recado = $_POST['recado'];
      $tipoderecado = $_POST['select_tipo'];
      $cd_destinatario = $_POST['select_destinatario'];

      $sql_recado = 'insert into tb_recado values(null, "'.$recado.'", "'.$cd_destinatario.'", "'.$_SESSION['cd_usuario'].'", "'.$tipoderecado.'")';

      if (!$query_recado = $mysqli->query($sql_recado)){
                        
         echo "Error%s/n", $mysqli -> error;
      }

     echo ' <meta http-equiv="refresh" content="0.0000001" />';
     
        }
  ?>