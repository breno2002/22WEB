<!DOCTYPE html>
<html>
<head>


<meta charset="utf-8">

	<?php 

  session_start();
  date_default_timezone_set("Brazil/East"); //Definindo timezone padrão
  include('includes/links.php');
  include('conexao.php');

   if (isset($_SESSION['login'])) {
  if ($_SESSION['login']==1) {

  if ($_SESSION['chave']==1) {
    header('location:admin.php');
  }

  if ($_SESSION['chave']==3) {
    header('location:responsavel.php');
  }
   
}
}

else{
  header('location:login.php');
}

  ?>
	<title>22WEB| Local do Professor</title>
</head>
<body>  

<form method="post" multipart='enctype/form-data'>
  <div class="row">
    
    <div class="col s5 m4 l3" id='menu'>
      <ul>
        <p>
          <h4>Professor</h4>
           <li><a href='chat.php'>chat</a></li>
           <li><a href='#modal_sair' class="modal-trigger">deslogar</a></li>
        </p>
      </ul>
    </div>

    <style type="text/css">
      #menu{
        background: black;
        text-decoration-color: white;
        height: 500%;
      }

      #menu, a{
        color: white;
      }
    </style>

   
    <div class="col s4 m5 l6" id='recados'>

      <ul>

      <p>

          <?php 

          $sql_mensagem = 'select * from tb_recado 
          inner join tb_usuario on(tb_usuario.cd_usuario = tb_recado.id_usuario_mandar)
          inner join tb_tiporecado on(tb_tiporecado.cd_tiporecado = tb_recado.id_tiporecado)
          order by tb_recado.cd_recado asc, tb_recado.id_tiporecado desc;';

          $query_mensagem = $mysqli->query($sql_mensagem);

          while ($row_msg = $query_mensagem->fetch_array()) {
            echo $row_msg['ds_recado'].'<br>';
          }

          ?>
      </p>

      <p>
      <textarea name="recado" id='txt'></textarea>
      </p>
    </ul>

    </div>

    <div class="col s2 m2 l1">
    <select name='select_tipo' id='tipo'>
        <?php
        $sql_recado = 'select * from tb_tiporecado';

        if ($query_recado = $mysqli->query($sql_recado)) {
          while ($row_recado = $query_recado->fetch_array()) {

                echo utf8_encode('<option name="tipoderecado" value="'.$row_recado['cd_tiporecado'].'">'.$row_recado['nm_tiporecado'].'</option>'); 

          }
        }

        
        ?>
    </select>
    </div>

     <div class="col s2 m2 l1">
    <select name='select_destinatario' id='dest'>
        <?php
        $sql_pessoas = 'select * from tb_usuario';

        if ($query_pessoas = $mysqli->query($sql_pessoas)) {
          while ($row_pessoas = $query_pessoas->fetch_array()) {
              if ($row_pessoas['cd_usuario'] == $_SESSION['cd_usuario']){
              }

              else{
                echo '<option name="destinatario" value="'.$row_pessoas['cd_usuario'].'">'.$row_pessoas['nm_usuario'].'</option>';  
              }
          }
        }

        
        ?>
    </select>
    </div>

    <div class="col s2 m2 l1">
    <button type="submit" class="btn btn-floating teal darken-4" id='send' name='enviar_recado' value=''>
      <i class="material-icons">send</i>
    </button>
    </div>

  </div>
  </form>

	<div class="row">
		<div class="col s8 m8 l7" id='a'>
			
		</div>
	</div>


	<script>
  
            $(document).ready(function(){

            $('select').formSelect();
            $('select2').formSelect();

            $('.modal, #modal_aluno').modal();
            $('.modal, #modal_responsavel').modal();
            $('.modal, #modal_professor').modal();
             // Show sideNav
                   $('.button-collapse').sideNav('show');
          });

  </script>

</body>
</html>

<style type="text/css">
	#menu{
		height: 200px;
	}

	#radio{
		height: 40px;
	}
</style>

<script type="text/javascript">

   $(document).ready(function(){

    $("#send").click(function(){

              var dados = {'destinatario' : $('#dest').val(), 'tipo' : $('#tipo').val(), 'recado' : $('#txt').val() };

               $.ajax({
                type:'POST',
                url:'ajax/recado.php',
                data: dados,
               });
               
            });

  });

</script>

<?php

  include('includes/admin/processos_php/recado.php');

  include('includes/admin/modal/include_modal_professor.php');
  include('includes/admin/modal/include_modal_aluno.php');
  include('includes/admin/modal/include_modal_responsavel.php');
  include('includes/admin/modal/include_modal_administrador.php');
  include('includes/admin/modal/modal_sair.php');

?>




